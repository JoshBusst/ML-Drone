

def newFunc():
    pi = 3.14
    e = 2.71828182845904523536
    c = 299792458
    maththing = c*pi*e

    debug(maththing)    



from Lib import debug


newFunc()