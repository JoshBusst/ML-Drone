

from time import sleep
from numpy import mean
from tensorflow.keras.models import load_model
from Simulation import *
from NeuralNet import *
from Drone import *
from Graphics import consoleInit, droneSpriteColours
from Lib import debug

consoleInit()


# TODO: update UI to run cleaner key tracking algorithm


if __name__ == "__main__":
    simulateStability = True

    if simulateStability:
        bestNet = load_model('models/stability')
    else:
        bestNet = createNet([6,8,8,2], "tanh")


    mRate = 0.2 # mutation rate
    numGenerations = 100
    bestScore = 10**6 # as score -> 0, performance improves

    for i in range(numGenerations):

        # initialise new simulation parameters
        sim = Simulation()
        sim.timeout = 10
        numDrones = len(droneSpriteColours)
        drones = initDrones(numDrones, netSeed=bestNet, mRate=mRate)
            
        sim.generation = i
        

        # score updates and net reparenting
        scores = simulate(sim, drones, addNoise=True)

        for i, score in enumerate(scores):
            if score < bestScore:
                bestNet = drones[i].net
                bestScore = score

                bestNet.save('model')
                print(f"Best score: {round(bestScore, 4)}")


